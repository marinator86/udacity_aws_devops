nd9991 - Project 1
Mario Hammer

This project demonstrates the ability of S3 and CloudFront to serve a static, CDN-cached website (here, a travel blog).
You can find the page by following any of these links:

s3 URL: https://nd9991-marinator-p1.s3.amazonaws.com/index.html
s3 website URL: http://nd9991-marinator-p1.s3-website-us-east-1.amazonaws.com/
CloudFront URL (CDN cached): https://d849tfyvncgag.cloudfront.net/